import { AssessmentCriterion, AssessmentPlanItem } from '../../types';
import { resolveScheduledLearningMeetings, ScheduledLearningMeetingProjection } from '../scheduledLearningMeetingProjectionService';
import { LearningPlan, DocumentGenerationContext } from './types';
import { validateLearningPlanForModulAjar, LearningPlanValidationResult, DEEP_LEARNING_PRINCIPLE_LABELS } from '../learningPlanService';
import { resolveLearningPlanMeetingBudgets } from '../learningPlanActivityMeetingService';

export interface ModulAjarMeetingActivity {
  id: string;
  learningMeetingId: string;
  phase: string;
  title?: string;
  description: string;
  durationMinutes?: number;
}
export interface ModulAjarMeeting {
  id: string; order: number; title: string; date: string; jp: number;
  minutesPerJP: number; durationMinutes: number;
  materials: ScheduledLearningMeetingProjection['materials'];
  linkedTpIds: string[]; linkedAtpItemIds: string[];
  atpSummary?: string;
  resolvedTPs: ModulAjarProjection['resolvedTPs'];
  assessments: AssessmentPlanItem[];
  activities: ModulAjarMeetingActivity[];
  activitiesStatus: 'COMPLETE' | 'INCOMPLETE';
  activityLines: string[];
  KKTP: Pick<AssessmentCriterion, 'id' | 'tpId' | 'description' | 'indicators'>[];
  kktpSummaryLines: string[];
}
export interface ModulAjarSection { title: string; lines: string[] }
export function formatModulAssessment(item: AssessmentPlanItem): string {
  return [item.type,item.description,item.method !== item.description ? item.method : '',
    item.technique,item.instrument,'TP: '+item.linkedTpIds.join(', ')].filter(Boolean).join(' | ');
}
export function modulDeepLearningLines(plan: LearningPlan): string[] {
  const framework = plan.deepLearningContext?.framework;
  return [
    ...(plan.materialCharacteristics ? ['Karakteristik Materi: '+plan.materialCharacteristics] : []),
    ...(plan.deepLearningContext?.principles?.length ? ['Prinsip Pembelajaran: '+plan.deepLearningContext.principles.map(p=>DEEP_LEARNING_PRINCIPLE_LABELS[p] || p).join(', ')] : []),
    ...([['Praktik Pedagogis',framework?.pedagogicalPractice],['Kemitraan Pembelajaran',framework?.learningPartnership],
      ['Lingkungan Pembelajaran',framework?.learningEnvironment],['Pemanfaatan Digital',framework?.digitalUtilization]] as const)
      .flatMap(([label,values])=>values?.length ? [label+': '+values.join('; ')] : []),
  ];
}
const phaseLabels: Record<string,string> = {opening:'Pendahuluan',core:'Kegiatan Inti',closing:'Penutup',UNDERSTAND:'Memahami',APPLY:'Mengaplikasi',REFLECT:'Merefleksi'};
function activityLinesFor(activities: Array<{phase:string;description:string;title?:string;durationMinutes?:number}>) {
  const same = (a:string,b:string) => a.trim().replace(/\s+/g,' ') === b.trim().replace(/\s+/g,' ');
  return activities.filter(a=>a.description?.trim()).filter(a=>!['UNDERSTAND','APPLY','REFLECT'].includes(a.phase) || !activities.some(step=>step.phase==='core' && same(step.description,a.description))).map(a=>{
    const approaches = a.phase==='core' ? activities.filter(exp=>['UNDERSTAND','APPLY','REFLECT'].includes(exp.phase) && same(exp.description,a.description)).map(exp=>phaseLabels[exp.phase]) : [];
    const isStep=['opening','core','closing'].includes(a.phase);
    return [phaseLabels[a.phase] || a.phase,...approaches].join(' / ')+': '+(a.title ? a.title+' — ' : '')+a.description+
      (isStep && a.durationMinutes ? ' ('+a.durationMinutes+' Menit)' : isStep ? '' : ' (pendekatan kegiatan inti)');
  });
}
export function modulGlobalActivityLines(plan: LearningPlan): string[] {
  return activityLinesFor([
    ...Object.entries(plan.learningSteps || {}).flatMap(([phase,steps])=>(steps || []).filter(step=>step.learningMeetingId===undefined).map(step=>({...step,phase}))),
    ...(plan.learningExperiences || []).filter(exp=>exp.learningMeetingId===undefined),
  ]);
}
export interface ModulAjarProjection {
  unitTitle?: string;
  meetings?: ModulAjarMeeting[];
  sections?: ModulAjarSection[];
  isReady: boolean;
  error?: string;

  plan?: LearningPlan;

  resolvedTPs: Array<{
    id: string;
    code?: string;
    statement: string;
    materialScope?: string;
  }>;

  resolvedAllocatedJP?: number;

  jpResolutionSource:
    | 'CANONICAL_MEETINGS'
    | 'EXPLICIT_PLAN'
    | 'LINKED_TIME_ALLOCATION'
    | 'UNRESOLVED';

  validation?: LearningPlanValidationResult;
}

export function buildModulAjarProjection(context: DocumentGenerationContext): ModulAjarProjection {


  const learningPlans = context.learningPlans || [];
  const activePlanId = context.activeLearningPlanId;

  let selectedPlan: LearningPlan | undefined;

  if (activePlanId) {
    const plan = learningPlans.find((p) => p.id === activePlanId);
    if (!plan) {
      return {
        isReady: false,
        error: `Rencana pembelajaran terpilih dengan ID "${activePlanId}" tidak ditemukan.`,
        resolvedTPs: [],
        resolvedAllocatedJP: undefined,
        jpResolutionSource: 'UNRESOLVED',
      };
    }
    if (context.workMode !== 'production' && plan.status !== 'SIAP') {
      return {
        isReady: false,
        error: `Rencana pembelajaran "${plan.topic || plan.id}" terpilih belum diubah statusnya menjadi SIAP.`,
        resolvedTPs: [],
        resolvedAllocatedJP: undefined,
        jpResolutionSource: 'UNRESOLVED',
      };
    }
    selectedPlan = plan;
  } else {
    const siapPlans = context.workMode === 'production' ? learningPlans : learningPlans.filter((p) => p.status === 'SIAP');
    if (siapPlans.length === 0) {
      return {
        isReady: false,
        error: 'Belum ada rencana pembelajaran (Modul Ajar) dengan status SIAP.',
        resolvedTPs: [],
        resolvedAllocatedJP: undefined,
        jpResolutionSource: 'UNRESOLVED',
      };
    }
    if (siapPlans.length > 1) {
      return {
        isReady: false,
        error: 'Terdapat lebih dari satu rencana pembelajaran (Modul Ajar) dengan status SIAP. Silakan pilih salah satu rencana secara eksplisit.',
        resolvedTPs: [],
        resolvedAllocatedJP: undefined,
        jpResolutionSource: 'UNRESOLVED',
      };
    }
    selectedPlan = siapPlans[0];
  }

  const validation = validateLearningPlanForModulAjar(selectedPlan, {
    academicSetting: context.academicSetting,
    tp: context.tp,
    atp: context.atp,
    atpUnitMapping: context.atpUnitMapping,
    unitExecutionPlan: context.unitExecutionPlan,
    learningMeetingSchedules: context.learningMeetingSchedules,
    k13Analysis: context.k13Analysis,
    timeAllocations: context.timeAllocations,
    assessmentCriteria: context.assessmentCriteria,
    calendar: context.calendar, calendarDays: context.calendarDays,
    subjectWeeklySchedule: context.subjectWeeklySchedule,
    semesterJPSetting: context.semesterJPSetting, annualJPReference: context.annualJPReference,
  });

  if (!validation.valid && context.workMode !== 'production') {
    return {
      isReady: false,
      error: validation.errors.join('; '),
      resolvedTPs: [],
      resolvedAllocatedJP: undefined,
      jpResolutionSource: 'UNRESOLVED',
      validation,
    };
  }

  const production = context.workMode === 'production';
  const objectives = validation.resolvedTPs.filter(tp => tp.statement?.trim());
  const masterActivities = [
    ...Object.entries(selectedPlan.learningSteps || {}).flatMap(([phase, steps]) => (steps || []).map(step => ({ ...step, phase }))),
    ...(selectedPlan.learningExperiences || []),
  ].filter(activity => activity.description?.trim());
  const minimumPresent = selectedPlan.academicSettingId === context.academicSetting.id && objectives.length > 0 && masterActivities.length > 0;
  if (production && !minimumPresent) return { isReady: false, error: 'Substansi minimum modul pada semester tujuan: TP terhubung dan kegiatan pembelajaran harus tersedia.', resolvedTPs: [], jpResolutionSource: 'UNRESOLVED', validation };
  const invalid = (error: string): ModulAjarProjection => {
    if (!production) return { isReady: false, error, resolvedTPs: [], jpResolutionSource: 'UNRESOLVED', validation };
    const assessments = Object.values(selectedPlan.assessmentPlan || {}).flatMap(items => items || []);
    const criteria = (context.assessmentCriteria || []).filter(criterion => selectedPlan.tpIds.includes(criterion.tpId));
    const sections = buildSections(selectedPlan, [], objectives, assessments, criteria);
    sections[2].lines = ['Jadwal/relasi pertemuan belum lengkap; kegiatan master ditampilkan tanpa menetapkan ulang tanggal.', ...modulGlobalActivityLines(selectedPlan)];
    return { isReady: true, plan: selectedPlan, resolvedTPs: objectives, meetings: [], sections:presentSections(context,selectedPlan,sections),
      unitTitle: context.atpUnitMapping?.units?.find(unit => unit.id === selectedPlan.unitId)?.title,
      resolvedAllocatedJP: validation.resolvedAllocatedJP, jpResolutionSource: 'UNRESOLVED', validation };
  };
  if (!selectedPlan.unitId || !selectedPlan.learningMeetingIds?.length ||
      !context.atpUnitMapping || !context.unitExecutionPlan || !context.learningMeetingSchedules?.length) {
    return invalid('Lineage Unit → Meeting → LearningPlan belum lengkap.');
  }
  if (context.snapshot?.learningPlanId &&
      (context.snapshot.learningPlanId !== selectedPlan.id ||
       context.snapshot.sourceVersions?.learningPlanUpdatedAt !== selectedPlan.updatedAt)) {
    return invalid('Lineage LearningPlan berbeda dari snapshot.');
  }
  const scheduled = resolveScheduledLearningMeetings({
    allowDraftWorkflow: production,
    mapping: context.atpUnitMapping, unitExecutionPlan: context.unitExecutionPlan,
    schedules: context.learningMeetingSchedules, tp: context.tp, atp: context.atp,
  });
  if (!scheduled.isValid && !production) return invalid(scheduled.errors.join('; '));
  const ids = selectedPlan.learningMeetingIds;
  const rows = scheduled.rows.filter(r => r.semesterPlanId === context.academicSetting.id && ids.includes(r.meetingId));
  const budgets = resolveLearningPlanMeetingBudgets(rows, context.academicSetting);
  if (!budgets.isValid) return invalid(budgets.reason!);
  if (new Set(ids).size !== ids.length || rows.length !== ids.length ||
      new Set(rows.map(r => r.meetingId)).size !== ids.length ||
      new Set(rows.map(r => r.meetingOrder)).size !== ids.length ||
      rows.some(r => r.unitId !== selectedPlan.unitId || !/^\d{4}-\d{2}-\d{2}$/.test(r.date) ||
        !Number.isFinite(Date.parse(r.date)) || !Number.isFinite(r.jp) || !(r.jp > 0) ||
        !Number.isInteger(r.meetingOrder) || r.meetingOrder < 1 ||
        !r.linkedTpIds.length || !r.linkedAtpItemIds.length ||
        r.linkedTpIds.some(id => !selectedPlan.tpIds.includes(id)) ||
        r.linkedAtpItemIds.some(id => !selectedPlan.atpItemIds.includes(id)))) {
    return invalid('Pertemuan atau lineage TP/ATP/Unit tidak valid.');
  }
  // Unlinked activities stay at unit level. Never infer a meeting from text, TP, or order.
  const activities = [
    ...Object.entries(selectedPlan.learningSteps || {}).flatMap(([phase, steps]) =>
      (steps || []).map(activity => ({ ...activity, phase }))),
    ...(selectedPlan.learningExperiences || []),
  ];
  const linkedActivities = activities.filter(a => a.learningMeetingId !== undefined);
  if (linkedActivities.some(a => typeof a.learningMeetingId !== 'string' ||
      !ids.includes(a.learningMeetingId) || !rows.some(r => r.meetingId === a.learningMeetingId))) {
    return invalid('Kegiatan pembelajaran memiliki learningMeetingId yang tidak valid pada Unit/LearningPlan aktif.');
  }
  const assessments = Object.values(selectedPlan.assessmentPlan).flatMap(items => items || []);
  const criteria = (context.assessmentCriteria || []).filter(c =>
    c.academicSettingId === context.academicSetting.id && selectedPlan.tpIds.includes(c.tpId) &&
    (!selectedPlan.kktpCriterionIds?.length || selectedPlan.kktpCriterionIds.includes(c.id)));
  if ((selectedPlan.kktpCriterionIds || []).some(id => !criteria.some(c => c.id === id))) {
    return invalid('Referensi KKTP tidak ditemukan pada TP dan semester LearningPlan.');
  }
  const meetings: ModulAjarMeeting[] = rows.sort((a,b) => a.meetingOrder - b.meetingOrder).map(r => {
    const meetingActivities: ModulAjarMeetingActivity[] = linkedActivities
      .filter(a => a.learningMeetingId === r.meetingId)
      .map(a => ({ ...a, learningMeetingId: r.meetingId }));
    const complete = meetingActivities.length > 0 && meetingActivities.every(a => a.description?.trim());
    const activityLines = activityLinesFor(meetingActivities);
    if (!complete) activityLines.push('Belum lengkap: kegiatan pembelajaran pertemuan belum tersedia atau deskripsinya belum diisi.');
    const KKTP = criteria.filter(c => r.linkedTpIds.includes(c.tpId))
      .map(c => ({ id: c.id, tpId: c.tpId, description: c.description, indicators: c.indicators }));
    return {
      id: r.meetingId, order: r.meetingOrder, title: r.meetingTitle, date: r.date, jp: r.jp,
      minutesPerJP: budgets.meetings.find(m => m.meetingId === r.meetingId)!.minutesPerJP,
      durationMinutes: budgets.meetings.find(m => m.meetingId === r.meetingId)!.durationMinutes,
      materials: r.materials, linkedTpIds: r.linkedTpIds, linkedAtpItemIds: r.linkedAtpItemIds,
      atpSummary:r.linkedAtpItemIds.map(id=>{const item=context.atp?.items.find(item=>item.id===id);return item ? 'Langkah '+item.stepNumber+(item.focus || item.materialScope ? ': '+(item.focus || item.materialScope) : '') : id;}).join('; '),
      resolvedTPs: validation.resolvedTPs.filter(t => r.linkedTpIds.includes(t.id)),
      assessments: assessments.filter(a => a.learningMeetingId === r.meetingId &&
        a.linkedTpIds.every(id => r.linkedTpIds.includes(id))),
      activities: meetingActivities, activitiesStatus: complete ? 'COMPLETE' : 'INCOMPLETE', activityLines,
      KKTP,
      kktpSummaryLines: KKTP.map(c => 'TP: ' + (validation.resolvedTPs.find(t => t.id === c.tpId)?.code || c.tpId) +
        ' | Kriteria: ' + c.description + ' | Indikator: ' + c.indicators.join('; ')),
    };
  });
  const sections = buildSections(selectedPlan, meetings, validation.resolvedTPs, assessments, criteria);

  const jpResolutionSource = validation.jpResolutionSource === 'CANONICAL_ATP'
    ? 'UNRESOLVED'
    : (validation.jpResolutionSource || 'UNRESOLVED');

  return {
    isReady: true,
    unitTitle: context.atpUnitMapping?.units.find(unit => unit.id === selectedPlan.unitId)?.title,
    plan: selectedPlan,
    meetings, sections:presentSections(context,selectedPlan,sections),
    resolvedTPs: validation.resolvedTPs || [],
    resolvedAllocatedJP: validation.resolvedAllocatedJP,
    jpResolutionSource,
    validation,
  };
}

/** A presentation of the existing sections; no second plan or pedagogy engine. */
function presentSections(context:DocumentGenerationContext,plan:LearningPlan,sections:ModulAjarSection[]):ModulAjarSection[] {
  if(context.learningPlanPresentation!=='RPM')return sections;
  const identification=(line:string)=>['Kompetensi Awal:','Dimensi Profil Lulusan:','Karakteristik/Kebutuhan Belajar Murid:','Karakteristik Materi:'].some(label=>line.startsWith(label));
  const general=sections[0].lines;
  const design=general.filter(line=>!identification(line));
  for(const [key,label] of [['pedagogicalPractice','Praktik Pedagogis'],['learningPartnership','Kemitraan Pembelajaran'],['learningEnvironment','Lingkungan Pembelajaran'],['digitalUtilization','Pemanfaatan Digital']] as const) {
    if(!design.some(line=>line.startsWith(label+':')))design.push(label+': '+(plan.deepLearningContext?.framework?.[key] ? 'Tidak direncanakan pada draf ini.' : 'Belum tercatat pada data tersimpan.'));
  }
  return [
    {title:'I. IDENTIFIKASI',lines:[...general.filter(identification),...(!plan.materialCharacteristics ? ['Karakteristik Materi: Belum tercatat pada data tersimpan.'] : [])]},
    {title:'II. DESAIN PEMBELAJARAN',lines:[...design,...sections[1].lines,...sections[4].lines,...sections[5].lines]},
    {title:'III. PENGALAMAN BELAJAR',lines:[...sections[2].lines,...sections[6].lines]},
    {title:'IV. ASESMEN',lines:sections[3].lines},
  ];
}


function buildSections(plan: LearningPlan, meetings: ModulAjarMeeting[], tps: ModulAjarProjection['resolvedTPs'], assessments: AssessmentPlanItem[], criteria: AssessmentCriterion[]): ModulAjarSection[] {
  const criterionLines = (items: AssessmentCriterion[]) => items.map(c =>
    [tps.find(t => t.id === c.tpId)?.code || c.tpId, c.description, c.approach,
      ...c.indicators, ...c.levels.map(l => (l.label || l.level) + ': ' + l.description),
      c.passingThreshold != null ? 'Ambang: ' + c.passingThreshold : '', c.notes].filter(Boolean).join(' | '));
  const assessmentLines = (items: AssessmentPlanItem[]) => items.map(formatModulAssessment);
  return [
    { title: 'I. INFORMASI UMUM', lines: [
      'Kompetensi Awal: ' + (plan.initialCompetency || '-'),
      'Dimensi Profil Lulusan: ' + (plan.graduateProfileDimensions?.length ? plan.graduateProfileDimensions : plan.p3Dimensions || []).join(', '),
      'Sarana dan Prasarana: ' + (plan.resources || []).map(r => r.title + (r.source ? ' (' + r.source + ')' : '')).join('; '),
      'Karakteristik/Kebutuhan Belajar Murid: ' + (plan.targetStudents || '-'),
      'Model/Praktik Pembelajaran: ' + (plan.learningModel || '-'), ...modulDeepLearningLines(plan)] },
    { title: 'II. KOMPONEN INTI', lines: [...tps.map(t => (t.code || t.id) + ': ' + t.statement + (t.materialScope ? ' (Materi: ' + t.materialScope + ')' : '')),
      'Pemahaman Bermakna: ' + (plan.meaningfulUnderstanding || '-'),
      'Pertanyaan Pemantik: ' + (plan.triggerQuestions || []).join('; '),
      ...(meetings.length ? modulGlobalActivityLines(plan) : [])] },
    { title: 'III. RENCANA PERTEMUAN', lines: meetings.flatMap(m => [
      'Pertemuan ' + m.order + ': ' + m.title + ' | ' + m.date + ' | ' + m.jp + ' JP | ' + m.durationMinutes + ' Menit',
      'Materi: ' + m.materials.map(x => x.title).join('; '),
      'ATP: ' + (m.atpSummary || m.linkedAtpItemIds.join(', ')),
      'TP:', ...m.resolvedTPs.map(t => (t.code || t.id) + ': ' + t.statement),
      'Kegiatan Pembelajaran:', ...m.activityLines,
      'Asesmen:', ...assessmentLines(m.assessments), 'KKTP ringkas:', ...m.kktpSummaryLines]) },
    { title: 'IV. ASESMEN + KKTP', lines: [...assessmentLines(assessments), ...criterionLines(criteria)] },
    { title: 'V. DIFERENSIASI', lines: Object.entries(plan.differentiation || {}).map(([key,value]) => key + ': ' + value) },
    { title: 'VI. PENGAYAAN/REMEDIAL', lines: ['Pengayaan: ' + (plan.enrichmentPlan || '-'), 'Remedial: ' + (plan.remedialPlan || '-')] },
    { title: 'VII. REFLEKSI', lines: ['Guru: ' + (plan.reflection?.teacherReflection || '-'), 'Murid: ' + (plan.reflection?.studentReflection || '-')] },
  ];
}
