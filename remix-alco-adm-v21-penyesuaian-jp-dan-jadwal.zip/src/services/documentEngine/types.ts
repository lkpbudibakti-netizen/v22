import {
  SchoolData,
  TeacherProfile,
  AcademicSetting,
  AdministrationWorkspace,
  CPData,
  TPData,
  ATPData,
  AppDocumentRecord,
  DocumentType,
  Student,
  AcademicCalendar,
  CalendarDay,
  TimeAllocation,
  AttendanceSession,
  AttendanceRecord,
  AssessmentCriterion,
  Assessment,
  AssessmentResult,
  RemedialRecord,
  EnrichmentRecord,
  K13Analysis,
  K13KKM,
  LearningPlan,
  AssessmentPlan,
  AssessmentPackage,
  DocumentMode,
  DocumentSnapshot,
  SemesterJPSetting,
  AnnualJPReference,
  ATPUnitMappingData,
  UnitExecutionPlanData,
  LearningMeetingScheduleData,
} from '../../types';
import type { AppStorageStateV5 } from '../../types/storageV5';

export type { DocumentType, DocumentMode, DocumentSnapshot, AppDocumentRecord, LearningPlan };

export interface ProtaSemesterAllocationBundle {
  capacityJP?: number | null;
  calendarLostJP?: number | null;
  semesterPlanId: string;
  semester: 1 | 2;
  allocations: TimeAllocation[];
}

export interface DocumentGenerationContext {
  journalRealizations?: import('../../types').JournalRealization[];
  subjectWeeklySchedule?: import('../../types').SubjectWeeklySchedule;
  /** Read-only canonical annual data exposure for ZIP packaging only. */
  zipAnnualSource?: Pick<AppStorageStateV5, 'semesterData' | 'semesterJPSettings'> & {
    yearPlan: import('../../types').YearPlan;
    semesterPlans: import('../../types').SemesterPlan[];
  };
  school: SchoolData;
  profile: TeacherProfile;
  academicSetting: AcademicSetting;
  workspace?: AdministrationWorkspace;
  documentMode?: DocumentMode; // 'data' | 'blank'
  snapshot?: DocumentSnapshot; // Preserved frozen snapshot for historical documents
  skipDownload?: boolean; // When true, generates document and returns blob without triggering browser saveAs
  effectiveWeeksCount?: number; // for PROMES (default 18 weeks/semester)
  cp?: CPData;
  tp?: TPData;
  atp?: ATPData;
  atpUnitMapping?: ATPUnitMappingData;
  unitExecutionPlan?: UnitExecutionPlanData;
  learningMeetingSchedules?: {
    semesterPlanId: string;
    semester: 1 | 2;
    schedule: LearningMeetingScheduleData;
  }[];
  students?: Student[];
  calendar?: AcademicCalendar;
  calendarDays?: CalendarDay[];
  timeAllocations?: TimeAllocation[];
  semesterJPSetting?: SemesterJPSetting;
  annualJPReference?: AnnualJPReference;
  protaSemesterAllocations?: ProtaSemesterAllocationBundle[];
  attendanceSessions?: AttendanceSession[];
  attendanceRecords?: AttendanceRecord[];
  assessmentCriteria?: AssessmentCriterion[];
  assessments?: Assessment[];
  assessmentResults?: AssessmentResult[];
  remedials?: RemedialRecord[];
  enrichments?: EnrichmentRecord[];
  k13Analysis?: K13Analysis;
  k13KKM?: K13KKM;
  learningPlans?: LearningPlan[];
  activeLearningPlanId?: string;
  assessmentPlans?: AssessmentPlan[];
  assessmentPackages?: AssessmentPackage[];
  activeAssessmentPackageId?: string;
  documentDate?: string;
}

export type ZipExportFormat = 'pdf' | 'docx' | 'both';

export interface ZipExportOptions {
  format?: ZipExportFormat;
  documentMode?: DocumentMode;
  types?: DocumentType[];
  folderStructure?: 'standard' | 'flat';
  onProgress?: (current: number, total: number, docTitle: string) => void;
  existingRecords?: AppDocumentRecord[];
}

export interface ZipExportItemStatus {
  type: DocumentType;
  instanceId?: string;
  instanceTitle?: string;
  status: 'SUCCESS' | 'PARTIAL' | 'SKIPPED' | 'FAILED';
  reason?: string;
  filesGenerated?: string[];
}

export interface ZipExportResult {
  success: boolean;
  isComplete?: boolean;
  zipFileName: string;
  zipBlob?: Blob;
  exportedCount: number;
  pdfCount: number;
  docxCount: number;
  foldersCreated: string[];
  snapshots: DocumentSnapshot[];
  itemResults?: ZipExportItemStatus[];
  requestedCount?: number;
  successCount?: number;
  partialCount?: number;
  skippedCount?: number;
  failedCount?: number;
}

export interface DocumentValidationResult {
  isValid: boolean;
  missingFields: string[];
  message?: string;
  targetStep?: 'profile' | 'academic' | 'cp' | 'tp' | 'atp' | 'assessment';
}

export interface GeneratedDocumentResult {
  success: boolean;
  type: DocumentType;
  title: string;
  fileName: string;
  record: AppDocumentRecord;
  blob?: Blob;
  document?: any;
}

export interface DocumentCatalogItem {
  id: string;
  type: DocumentType;
  category: 'Perencanaan Utama' | 'Perangkat Pembelajaran' | 'Pelaksanaan & Asesmen' | 'Tindak Lanjut' | 'Kurikulum 2013';
  title: string;
  description: string;
  requiredSources: string[];
}
